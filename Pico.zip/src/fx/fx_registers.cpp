/*
 * NR-RetroWorks SuperFX3 Firmware
 * Copyright (C) 2026 NR-RetroWorks
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 3 or later.
 */
#include "fx_core.h"
#include "pico.h"

// Mesen-derived: SFR low-byte packing follows MesenCE GsuFlags::GetFlagsLow().
uint8_t __not_in_flash_func(SuperFx::flags_low)() const {
    return static_cast<uint8_t>((state_.flags.zero << 1) | (state_.flags.carry << 2) |
                                (state_.flags.sign << 3) | (state_.flags.overflow << 4) |
                                (state_.flags.running << 5) | (state_.flags.rom_read_pending << 6));
}

// Mesen-derived: SFR high-byte packing follows MesenCE GsuFlags::GetFlagsHigh().
uint8_t __not_in_flash_func(SuperFx::flags_high)() const {
    return static_cast<uint8_t>((state_.flags.alt1 << 0) | (state_.flags.alt2 << 1) |
                                (state_.flags.imm_low << 2) | (state_.flags.imm_high << 3) |
                                (state_.flags.prefix << 4) | (state_.flags.irq << 7));
}

// SNES CPU -> GSU register read
// FX3 relocates the GSU MMIO area to $7000-$7FFF. The $300-byte register/cache
// block mirrors every $400, while each $x300-$x3FF quarter is open bus. Internally
// the core retains the normal $3000-$32FF addresses so register handling stays shared.
// Mesen-derived: closely follows MesenCE Gsu::Read(), with the running-state gate explicit.
// NOTE: Open-bus reads use Nintendo-style 0xFF instead of MesenCE's 0x00 fallback.
uint8_t __not_in_flash_func(SuperFx::cpu_read)(uint16_t addr) {
    if (config_.chip == FxChip::FX3 && (addr & 0xF000) == 0x7000) {
        if ((addr & 0x0300) == 0x0300) return 0xFF;
        addr = static_cast<uint16_t>(0x3000 | (addr & 0x03FF));
    } else
        addr &= 0x33FF;

    // While executing, only SFR/VCR are readable.
    // FX3 additionally allows R15 polling.
    if (state_.flags.running) {
        bool allowed = addr == 0x3030 || addr == 0x3031 || addr == 0x303B;

        // FX3 has no completion IRQ.
        // R15 may be polled while running.
        if (config_.chip == FxChip::FX3 && (addr == 0x301E || addr == 0x301F))
            allowed = true;

        if (!allowed) return 0xFF;
    }

    // R0-R15
    if (addr >= 0x3000 && addr <= 0x301F) {
        const uint8_t reg = (addr >> 1) & 0x0F;

        if (addr & 1)
            return static_cast<uint8_t>(state_.r[reg] >> 8);
        else
            return static_cast<uint8_t>(state_.r[reg]);
    }

    switch (addr) {
        // SFR low
        case 0x3030:
            return flags_low();

        // SFR high
        // Reading clears GSU IRQ.
        case 0x3031: {
            const uint8_t result = flags_high();

            state_.flags.irq = false;
            if (backend_.set_irq) backend_.set_irq(backend_.context, false);

            return result;
        }

        case 0x3034: // PBR
            return state_.program_bank;

        case 0x3036: // ROMBR
            return state_.rom_bank;

        case 0x303B: // VCR
            return config_.chip == FxChip::FX3 ? 0x52 : 0x04;

        case 0x303C: // RAMBR
            return state_.ram_bank;

        case 0x303E: // CBR
            return static_cast<uint8_t>(state_.cache_base);

        case 0x303F:
            return static_cast<uint8_t>(state_.cache_base >> 8);
    }

    // Program cache: $3100-$32FF
    if (addr >= 0x3100 && addr <= 0x32FF) {
        const uint16_t cache_addr = (state_.cache_base + (addr - 0x3100)) & 0x01FF;
        return cache_[cache_addr];
    }

    // Unmapped register/cache addresses are treated as open bus.
    return 0xFF;
}

// Mesen-derived: closely follows MesenCE Gsu::Write(), adapted to the relocated FX3 register window.
void __not_in_flash_func(SuperFx::cpu_write)(uint16_t addr, uint8_t value) {
    if (config_.chip == FxChip::FX3 && (addr & 0xF000) == 0x7000) {
        if ((addr & 0x0300) == 0x0300) return;
        addr = static_cast<uint16_t>(0x3000 | (addr & 0x03FF));
    } else
        addr &= 0x33FF;

    // While executing, SNES may only modify SFR and SCMR.
    if (state_.flags.running && addr != 0x3030 && addr != 0x303A)
        return;

    // R0-R15
    if (addr >= 0x3000 && addr <= 0x301F) {
        const uint8_t reg = (addr >> 1) & 0x0F;

        if (!(addr & 1)) {
            // Low byte latch
            state_.register_latch = value;

        } else {
            // High byte commits entire register.
            state_.r[reg] = static_cast<uint16_t>(state_.register_latch | (static_cast<uint16_t>(value) << 8));

            // R14 initiates ROM-buffer fetch.
            if (reg == 14) {
                state_.flags.rom_read_pending = true;
                state_.rom_delay = state_.clock_select ? 5 : 6;
            }

            // Writing R15 high starts execution.
            if (reg == 15) {
                state_.flags.running = true;
                update_running_state();
            }
        }

        return;
    }

    switch (addr) {
        // SFR
        case 0x3030: {
            const bool was_running = state_.flags.running;
            state_.flags.zero = (value & 0x02) != 0;
            state_.flags.carry = (value & 0x04) != 0;
            state_.flags.sign = (value & 0x08) != 0;
            state_.flags.overflow = (value & 0x10) != 0;
            state_.flags.running = (value & 0x20) != 0;

            // Stopping the GSU clears program cache state.
            if (was_running && !state_.flags.running) {
                state_.cache_base = 0;
                invalidate_cache();
            }

            update_running_state();
            break;
        }

        // BRAMR
        case 0x3033:
            state_.backup_ram_enabled = (value & 0x01) != 0;
            break;

        // PBR
        case 0x3034:
            // Keep the documented/reference 7-bit model for now. The sd2snes FX3
            // branch deliberately experiments with bit 7 and notes that Mesen disagrees.
            state_.program_bank = value & 0x7F;
            invalidate_cache();
            break;

        // CFGR
        case 0x3037:
            state_.high_speed = (value & 0x20) != 0;
            state_.irq_disabled = (value & 0x80) != 0;
            break;

        // SCBR
        case 0x3038:
            state_.screen_base = value;
            break;

        // CLSR
        case 0x3039:
            state_.clock_select = (value & 0x01) != 0;
            break;

        // SCMR
        case 0x303A:
            state_.color_gradient = value & 0x03;
            switch (state_.color_gradient) {
                case 0:
                    state_.plot_bpp = 2;
                    break;
                case 1:
                case 2:
                    state_.plot_bpp = 4;
                    break;
                case 3:
                    state_.plot_bpp = 8;
                    break;
            }

            state_.screen_height = ((value & 0x04) >> 2) | ((value & 0x20) >> 4);
            state_.gsu_ram_access = (value & 0x08) != 0;
            state_.gsu_rom_access = (value & 0x10) != 0;

            // SNES just gave GSU ownership.
            if (state_.gsu_ram_access) wait_for_ram_access_ = false;
            if (state_.gsu_rom_access) wait_for_rom_access_ = false;

            update_running_state();
            break;
    }

    // Program cache writes
    if (addr >= 0x3100 && addr <= 0x32FF) {
        const uint16_t cache_addr = (state_.cache_base + (addr - 0x3100)) & 0x01FF;

        cache_[cache_addr] = value;

        // Cache line becomes valid once its final byte has been written.
        if ((cache_addr & 0x0F) == 0x0F) {
            cache_valid_[cache_addr >> 4] = true;
        }
    }
}
